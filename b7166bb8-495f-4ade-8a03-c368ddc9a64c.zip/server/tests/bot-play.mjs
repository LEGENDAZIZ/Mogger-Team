import * as L from './.logic.test.js';
let seed = 777; const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
// specific check: 3 small mwir
{ const S = L.SCN.fire; for (const [n, orbit, rocket] of [[3, 'sso525', 'rideSSO'], [2, 'sso700', 'alpha'], [2,'sso700','f9']]) { const d = Object.assign(JSON.parse(JSON.stringify(S.start)), { bus: 'small', inst: ['mwir'], sats: n, orbit, rocket, adcs: 'rw', array: 'fixed', arraySize: 1, batt: 1, prop: 'hydra', fuel: 2, band: 'x', net: 'com', contact: 1, plan: 'full' }); L.normalize(S, d); const M = L.compute(S, d, 'engineer'); console.log('mwir', n, orbit, rocket, 'cost', M.total.toFixed(1), 'rev', M.revisit.toFixed(1), 'thr', M.thr.toFixed(1), 'sci', M.sciRate.toFixed(0), 'wet', M.wet.toFixed(0), 'pM', M.pMargin.toFixed(2), 'reds', M.issues.filter(i => i.sev !== 'amber').map(i => i.msg).join(' | '), 'data', M.genGB.toFixed(0), M.downGB.toFixed(0), 'dv', M.dv.toFixed(3), M.dvNeed.toFixed(3)); } }
function randomDesign(S, id) { const d = JSON.parse(JSON.stringify(S.start));
  d.bus = pick(S.opts.bus); d.orbit = pick(S.opts.orbit); d.rocket = pick(S.opts.rocket); d.sats = 1 + Math.floor(rnd() * S.maxSats); d.test = pick(['min', 'std', 'full']);
  d.array = pick(['body', 'fixed', 'track']); d.arraySize = Math.floor(rnd() * 7); d.batt = Math.floor(rnd() * 4); d.prop = pick(S.opts.prop); d.fuel = Math.floor(rnd() * 10); d.adcs = pick(S.opts.adcs); d.comp = pick(['cots', 'radtol', 'radhard']);
  d.inst = S.opts.inst.filter(() => rnd() < 0.4); d.plan = pick(['target', 'region', 'full']); d.band = pick(S.opts.band); d.dish = Math.floor(rnd() * 3); d.net = pick(S.opts.net); d.contact = Math.floor(rnd() * 3); d.window = id === 'mars' ? pick([2, 3, 3, 3, 4]) : 0; return L.normalize(S, d); }
const KEYS = ['bus', 'orbit', 'window', 'rocket', 'sats', 'test', 'array', 'arraySize', 'batt', 'prop', 'fuel', 'adcs', 'comp', 'plan', 'band', 'dish', 'net', 'contact'];
let rejects = {};
for (const id of ['first', 'fire', 'aral', 'mars']) for (const mode of ['valid', 'any']) {
  const S = L.SCN[id]; const res = []; let stuck = 0;
  for (let g = 0; g < 250; g++) {
    let d; for (let k = 0; k < 4000; k++) { d = randomDesign(S, id); const M = L.compute(S, d, 'engineer'); if (M.blocks) continue; if (mode === 'any' || (!M.reds && M.reqs.every(r => r.ok))) break; d = null; }
    if (!d) continue;
    const np = 1 + Math.floor(rnd() * 4), P = ['p1', 'p2', 'p3', 'p4'].slice(0, np);
    let st = L.setup([P[0]]);
    const act = (p, a, quiet) => { const v = L.validateAction(st, p, a); if (!v.ok) { if (!quiet) rejects[a.type + ':' + v.error] = (rejects[a.type + ':' + v.error] || 0) + 1; return false; } st = L.applyAction(st, p, a); JSON.stringify(L.viewFor(st, p)); return true; };
    P.forEach((p, i) => act(p, { type: 'sit', name: 'Bot ' + i })); act(P[0], { type: 'config', scn: id, diff: pick(['cadet', 'engineer', 'director']) }); if (np > 1) act(P[1], { type: 'role', role: 'science' });
    let t = 1e6; act(P[0], { type: 'start', t }); act(P[0], { type: 'ready', t: t += 1000 });
    const own = (r) => st.roles[r];
    for (let pass = 0; pass < 2; pass++) for (const k of KEYS) { const c = L.controls(S, st.design, st.diff).find(x => x.key === k); if (c && st.design[k] !== d[k]) act(own(c.role), { type: 'set', key: k, value: d[k] }, true); }
    for (const i of S.opts.inst) if ((st.design.inst.indexOf(i) >= 0) !== (d.inst.indexOf(i) >= 0)) act(own('science'), { type: 'set', key: 'inst', value: i }, true);
    if (JSON.stringify(st.design) !== JSON.stringify(d)) rejects['designMismatch'] = (rejects['designMismatch'] || 0) + 1;
    act(own('director'), { type: 'toReview', t: t += 200000 }); P.forEach(p => act(p, { type: 'vote', go: rnd() < 0.9 }, true));
    if (!act(own('director'), { type: 'go', t: t += 5000 })) { stuck++; continue; }
    act(own('director'), { type: 'launch', rating: 0.4 + 0.6 * rnd(), t: t += 60000 });
    if (st.phase === 'capture') act(own('engineer'), { type: 'capture', rating: 0.5 + 0.5 * rnd(), dvUsed: 1, captured: rnd() < 0.95 });
    let guard = 0;
    while (st.phase === 'ops' && guard++ < 60) { if (st.event) { const o = st.event.opts.filter(x => !x.off); if (rnd() < 0.1) act(P[0], { type: 'timeout', t: st.event.t0 + 50000 }); else act(own(st.event.role), { type: 'respond', opt: pick(o).id, ms: 3000 + rnd() * 30000, t: t += 1000 }); } else act(P[0], { type: 'next', t: t += 1000 }); }
    if (st.phase !== 'report') { stuck++; continue; }
    res.push(st.report);
    if (g % 20 === 0) act(P[0], { type: 'again', mode: pick(['fly', 'design', 'lobby']), t: t += 1 });
  }
  const tot = res.map(r => r.total).sort((a, b) => a - b), stars = [0, 0, 0, 0]; res.forEach(r => stars[r.stars]++);
  const avg = (i) => Math.round(res.reduce((s, r) => s + r.parts[i][1], 0) / res.length);
  console.log(id, mode, 'games', res.length, 'stuck', stuck, 'lost', res.filter(r => r.lost).length, 'score min/med/max', tot[0], tot[tot.length >> 1], tot[tot.length - 1], 'stars', stars.join('/'), 'parts avg', [0, 1, 2, 3, 4].map(avg).join('/'));
  if (mode === 'valid') { const r = res.find(r => !r.lost); console.log('  sample:', r.total, r.stars, JSON.stringify(r.parts), '\n  ', r.why.slice(0, 6).map(w => (w.ok ? '+' : '-') + w.t).join('\n   ')); }
}
console.log('rejects', JSON.stringify(rejects));
