#!/bin/sh
# Automatic play-testers. Run from app/: sh tests/bot.sh
# 1) bot-play: plays hundreds of full missions with random designs and random answers, looking for stuck states.
# 2) bot-flight: flies the launch and the Mars braking burn with the flight computer to prove they can be done.
cd "$(dirname "$0")" || exit 1
{ cat ../src/logic.js; echo 'export { compute, SCN, controls, capDv, windows, normalize };'; } > .logic.test.js
node bot-play.mjs && node bot-flight.mjs && node bot-coach.mjs
rm -f .logic.test.js
