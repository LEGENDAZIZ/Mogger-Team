import * as L from './.logic.test.js';
for (const scn of ['first', 'fire', 'aral', 'mars']) for (const diff of ['cadet', 'engineer']) {
  let st = L.setup(['a']); const act = (a) => { const v = L.validateAction(st, 'a', a); if (!v.ok) return v.error; st = L.applyAction(st, 'a', a); return null; };
  act({ type: 'sit', name: 'kid' }); act({ type: 'config', scn, diff }); act({ type: 'start', t: 1 }); act({ type: 'ready', t: 2 });
  const rank = { block: 0, red: 1, amber: 2 }; let steps = 0, stop = '';
  for (; steps < 40; steps++) { const v = L.viewFor(st, 'a'); const Ls = v.issues.filter(i => i.sev !== 'amber').sort((a, b) => rank[a.sev] - rank[b.sev]); if (!Ls.length) break; const i = Ls[0];
    if (!i.go) { stop = 'NO GO: ' + i.msg; break; } const c = v.controls.find(x => x.key === i.go.k); if (!c) { stop = 'no control ' + i.go.k + ': ' + i.msg; break; }
    let err; if (c.type === 'step') err = act({ type: 'set', key: c.key, value: c.value + 1 }); else if (i.go.o === undefined || i.go.o === null || i.go.o === '') { stop = 'no option for ' + c.key + ': ' + i.msg; break; } else if (c.type === 'multi' && c.value.includes(i.go.o)) { stop = 'already has ' + i.go.o + ': ' + i.msg; break; } else if (c.type !== 'multi' && c.value === i.go.o) { stop = 'already set ' + i.go.o + ': ' + i.msg; break; } else err = act({ type: 'set', key: c.key, value: i.go.o });
    if (err) { stop = 'rejected ' + c.key + '=' + i.go.o + ' (' + err + '): ' + i.msg; break; } }
  const v = L.viewFor(st, 'a'); console.log(scn, diff, 'steps', steps, 'reqs', v.reqs.map(r => r.ok ? 'ok' : 'NO').join(' '), 'cost', v.M.total.toFixed(1) + '/' + v.M.budget.toFixed(1), 'sci', Math.round(v.M.sciPct * 100) + '%', stop ? '\n   STOP ' + stop : '', '\n   design', JSON.stringify(st.design));
}
