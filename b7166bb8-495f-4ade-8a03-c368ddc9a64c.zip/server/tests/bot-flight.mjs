import * as P from '../public/sim.js';
for (const GK of [45, 60, 80]) { P.LV.GK = GK;
for (const target of [200, 350, 525, 700]) {
  const s = P.launchInit(); let done = false, n = 0;
  while (!done && n < 400000 && !s.crashed) { const g = P.launchGuide(s, target); P.launchStep(s, 0.1, g.pitch, g.on); done = !!g.done; n++; if (s.b2 >= P.LV.T2) break; }
  const i = P.launchInfo(s);
  console.log(GK, 'launch', target, 't', Math.round(s.t), 'apo', Math.round(i.apo), 'peri', Math.round(i.peri), 'fuel2', i.fuel2.toFixed(2), 'crash', s.crashed, 'rating', P.launchRating(s, target).toFixed(2));
}}
